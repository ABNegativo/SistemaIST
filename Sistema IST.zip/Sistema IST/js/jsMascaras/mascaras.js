// Função para adicionar a máscara de CPF com limitação de 11 dígitos
function aplicarMascaraCPF(cpf) {
    cpf = cpf.replace(/\D/g, ""); // Remove qualquer caractere não numérico
    cpf = cpf.substring(0, 11); // Limita a 11 caracteres numéricos
    cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2"); // Adiciona o primeiro ponto
    cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2"); // Adiciona o segundo ponto
    cpf = cpf.replace(/(\d{3})(\d{1,2})$/, "$1-$2"); // Adiciona o hífen
    return cpf;
  }
  
  // Função para adicionar a máscara de data com limitação de 8 dígitos
  function aplicarMascaraData(data) {
    data = data.replace(/\D/g, ""); // Remove qualquer caractere não numérico
    data = data.substring(0, 8); // Limita a 8 caracteres numéricos
    data = data.replace(/(\d{2})(\d)/, "$1/$2"); // Adiciona a primeira barra
    data = data.replace(/(\d{2})(\d)/, "$1/$2"); // Adiciona a segunda barra
    return data;
  }
  
  // Função para aplicar as máscaras nos inputs quando eles existirem
  function aplicarMascarasNosInputs() {
    const cpfInput = document.getElementById('cpf');
    const dataNascimentoInput = document.getElementById('dataNascimento');
    const dataColetaInput = document.getElementById('dataColeta');
  
    // Se o input de CPF existe, aplicar a máscara e limitar a entrada
    if (cpfInput) {
      cpfInput.maxLength = 14; // Limita o input a 14 caracteres (incluindo pontos e hífen)
      cpfInput.addEventListener('input', function (e) {
        e.target.value = aplicarMascaraCPF(e.target.value);
      });
    }
  
    // Se o input de data de nascimento existe, aplicar a máscara e limitar a entrada
    if (dataNascimentoInput) {
      dataNascimentoInput.maxLength = 10; // Limita o input a 10 caracteres (incluindo as barras)
      dataNascimentoInput.addEventListener('input', function (e) {
        e.target.value = aplicarMascaraData(e.target.value);
      });
    }
  
    // Se o input de data de coleta existe, aplicar a máscara e limitar a entrada
    if (dataColetaInput) {
      dataColetaInput.maxLength = 10; // Limita o input a 10 caracteres (incluindo as barras)
      dataColetaInput.addEventListener('input', function (e) {
        e.target.value = aplicarMascaraData(e.target.value);
      });
    }
  }
  
  // Função para observar mudanças no DOM e verificar quando os inputs são adicionados
  function observarMudancasNoDOM() {
    // Define o alvo (geralmente o body) onde as mudanças no DOM podem ocorrer
    const alvo = document.body;
  
    // Cria uma instância de MutationObserver
    const observer = new MutationObserver(function (mutations) {
      mutations.forEach(function (mutation) {
        // Verifica se novos nós foram adicionados
        if (mutation.addedNodes.length) {
          // Tenta aplicar as máscaras nos inputs sempre que algo for adicionado
          aplicarMascarasNosInputs();
        }
      });
    });
  
    // Configura o observer para observar mudanças na árvore do DOM
    observer.observe(alvo, { childList: true, subtree: true });
  }
  
  // Chama a função para observar mudanças no DOM
  observarMudancasNoDOM();
  